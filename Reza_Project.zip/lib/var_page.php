<?php
$adm_arr = array("add_artikel","add_page","delete","delete_p","edit","edit_p","home","list_article","list_page");
$pg_arr = array("about","article","home","search");
$url_arr = array("!","@","#","$","%","^","&","*","(",")","/","\\",";","'","\"");
