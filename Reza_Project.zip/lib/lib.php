<?php
  define('LIB', '1');
  $PATH_LIB = "lib/";
  //Pemanggilan file yang ada
  require_once($PATH_LIB."config.php");
  require_once($PATH_LIB."var.php");
  require_once($PATH_LIB."var_page.php");
  require_once($PATH_LIB."page.php");
