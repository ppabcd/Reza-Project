<?php
  error_reporting(0);
  $JML_DATA = "5";
  $HOST = "http://localhost/projeka/";
  require_once("lib/lib.php");
 ?>
