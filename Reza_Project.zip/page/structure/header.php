<header>
  <div class="logo">
    <h1>Reza Juliandri</h1>
  </div>
  <div class="menu">
      <nav class="menu-utama">
      <ul>
        <a href="<?php echo base_url() ?>"><li>Home</li></a>
        <a href="<?php echo base_url() ?>?page=about"><li>About</li></a>
      </ul>
    </nav>
  </div>
  <div class="respon" hilang="ya" style="display:none">
    <a href="#"><i class="fa fa-align-justify" aria-hidden="true"></i></a>
  </div>
</header>
