<?php
defined("PAGE") or die("Access Denied");
?>
<h1>Dashboard</h1>
<p>
  Selamat Datang Dihalaman Admin. Disini anda akan mengelola halaman utama pada website. Klik navigasi pada sidebar halaman ini.
</p>
