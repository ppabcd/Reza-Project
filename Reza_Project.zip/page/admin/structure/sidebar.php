<div class="sidebar-adm">
  <div class="admin-sidebar">
    <span class="admin-header">Main Navigation</span>
      <ul class="admin-content">
        <a href="<?php echo base_url() ?>?admin"><li>Dashboard</li></a>
        <a href="<?php echo base_url() ?>?admin&amp;&amp;page=list_article"><li>Artikel</li></a>
        <a href="<?php echo base_url() ?>?admin&amp;&amp;page=list_page"><li>Page</li></a>
        <a href="#"><li>Change User Data</li></a>
      </ul>
  </div>
</div>
