<header>
  <div class="logo">
    <h1>Reza Juliandri</h1>
  </div>
  <div class="respon" hilang="ya">
    <a href="#"><i class="fa fa-align-justify" aria-hidden="true"></i></a>
  </div>
</header>
